/*-----------------------------------------------------------------------------
  Date			: 1 October 2009
  SQL Version	: SQL Server 2005/2008
  Author		: Jacob Sebastian
  Email			: jacob@beyondrelational.com
  Twitter		: @jacobsebastian
  Blog			: http://beyondrelational.com/blogs/jacob
  Website		: http://beyondrelational.com

  Summary:
  Script to create a basic XML Schema Collection

  Disclaimer:  
  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
  TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
  PARTICULAR PURPOSE.
-----------------------------------------------------------------------------*/
--CREATE DATABASE demo
--go

USE Demo
GO

IF OBJECT_ID('Orders') IS NOT NULL DROP TABLE Orders 

IF EXISTS(SELECT * FROM sys.xml_schema_collections WHERE name = 'OrderInfo')
	DROP XML SCHEMA COLLECTION OrderInfo

CREATE XML SCHEMA COLLECTION OrderInfo AS '
<xsd:schema xmlns:xsd="http://www.w3.org/2001/XMLSchema">
	 <xsd:element name="Order"/>
</xsd:schema>'
GO
