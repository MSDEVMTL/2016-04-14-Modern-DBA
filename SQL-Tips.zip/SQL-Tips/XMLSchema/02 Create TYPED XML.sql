/*-----------------------------------------------------------------------------
  Date			: 1 October 2009
  SQL Version	: SQL Server 2005/2008
  Author		: Jacob Sebastian
  Email			: jacob@beyondrelational.com
  Twitter		: @jacobsebastian
  Blog			: http://beyondrelational.com/blogs/jacob
  Website		: http://beyondrelational.com

  Summary:
  Script to declare and use TYPED XML columns.

  Disclaimer:  
  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
  TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
  PARTICULAR PURPOSE.
-----------------------------------------------------------------------------*/
use demo
go

-- Create a TYPED XML Variable
DECLARE @Ord XML(OrderInfo)
-- This will succeed
SELECT @Ord = '<Order>somevalue</Order>'

DECLARE @Ord XML(OrderInfo)
-- This will fail
SELECT @Ord = '<order>Jacob</order>'  -- Why ?  
------------------------------------------------

-- Create a table with TYPED XML Column
IF OBJECT_ID('Orders','U') IS NOT NULL 
	DROP TABLE Orders
GO
CREATE TABLE Orders (
	OrderID INT IDENTITY,
	OrderInfo XML
)

-- Add a TYPED XML Column to an existing table
ALTER TABLE Orders ADD NewCol XML(OrderInfo)
SELECT * FROM Orders
GO 

-- Altering a TYPED XML column to UNTYPED
INSERT INTO Orders(OrderInfo) SELECT '<Name>Jacob</Name>'

ALTER TABLE Orders ALTER COLUMN OrderInfo XML
INSERT INTO Orders(OrderInfo) SELECT '<Name>Jacob</Name>'

-- Altering an UNTYPED XML column to TYPED
ALTER TABLE Orders ALTER COLUMN OrderInfo XML(OrderInfo)

UPDATE Orders SET OrderInfo = NULL 
ALTER TABLE Orders ALTER COLUMN OrderInfo XML(OrderInfo)
