USE [DataMask]
GO

/****** Object:  Table [dbo].[Person]    Script Date: 4/3/2016 5:47:27 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[Person](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Fname] [varchar](50) NULL,
	[LName] [varchar](50) NULL,
	[email] [varchar](50) NULL,
	[SSN] [varchar](11) NULL,
	[birthday] [datetime] NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO


INSERT INTO [dbo].[Person]
           ([Fname]
           ,[LName]
           ,[email]
           ,[SSN]
           ,[birthday])
SELECT TOP (10) 
  [Fname] = RIGHT(o.name, 8), 
  [LName]  = LEFT(o.name, 12), 
  Email     = LEFT(o.name, 9) + '@' + RIGHT(o.name, 11) + '.net',
  SSN       = STUFF(STUFF(RIGHT('000000000' 
            + RTRIM(ABS(CHECKSUM(NEWID()))),9),4,0,'-'),7,0,'-'),
  BirthDate = DATEADD(DAY, -ABS(CHECKSUM(NEWID())%10000), o.modify_date)
FROM sys.all_objects AS o


