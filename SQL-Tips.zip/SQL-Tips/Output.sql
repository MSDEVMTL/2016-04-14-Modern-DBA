-- Output introcude in SQL Server 2005
-- https://www.mssqltips.com/sqlservertip/1381/sql-server-trigger-alternatives-with-the-output-clause



CREATE TABLE [dbo].[User_Audit](
	[ID_Audit] [INT] IDENTITY(1,1) NOT NULL,
	[UserID] [INT] NOT NULL,
	[Type] [NCHAR](10) NULL,
	[Environment] [NCHAR](10) NOT NULL,
	[Name] [NVARCHAR](50) NULL,
	[email] [NVARCHAR](255) NULL,
[ModifiedDate] [datetime] NULL,
[EnteredDate] [datetime] NULL,
[UserName] [varchar](100),
CONSTRAINT [PK_User_Audit1] PRIMARY KEY CLUSTERED 
(
[ID_Audit] ASC
)WITH (PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO 

-- ==============================================================

INSERT INTO [dbo].[User]
           ([Environment]
           ,[Type]
           ,[Name]
           ,[email])
OUTPUT INSERTED.ID
,INSERTED.[Environment]
           ,INSERTED.[Type]
           ,INSERTED.[Name]
           ,INSERTED.[email]
,GETDATE()
,GETDATE()
,SUSER_SNAME()
INTO [dbo].[User_Audit]

VALUES            ('DEV'
           ,'USER'
           ,'Joe Ticoune'
           ,'Ticoune@DomF.Com')