--USE Master 
--IF  EXISTS (SELECT name FROM sys.databases WHERE name = N'ForXML')
--DROP DATABASE [ForXML]
--GO

--CREATE DATABASE ForXML
--Go

USE ForXML
go
/****** Object:  Table [dbo].[Notification]    Script Date: 9/19/2015 4:31:25 PM ******/
DROP TABLE [dbo].[Notification]
GO

/****** Object:  Table [dbo].[Notification]    Script Date: 9/19/2015 4:31:25 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Notification](
	[ID] [INT] IDENTITY(1,1) NOT NULL,
	[Type] [NCHAR](10) NULL,
	[Environment] [NCHAR](10) NOT NULL,
	[Name] [NVARCHAR](50) NULL,
	[email] [NVARCHAR](255) NULL
) ON [PRIMARY]

GO


INSERT INTO [dbo].[Notification]
           ([Environment]
           ,[Type]
           ,[Name]
           ,[email])
     VALUES
           ('DEV'
           ,'USER'
           ,'Jean-Rene Roy'
           ,'jean-rene.roy@parl.gc.ca'),
           ('DEV'
           ,'USER'
           ,'Brazdau, Aurelian'
           ,'Aurelian.Brazdau@parl.gc.ca'),
           ('TEST'
           ,'ADMIN'
           ,'Jean-Rene Roy'
           ,'jean-rene.roy@parl.gc.ca'),
           ('TEST'
           ,'ADMIN'
           ,'Brazdau, Aurelian'
           ,'Aurelian.Brazdau@parl.gc.ca')

GO
/****** Object:  Table [dbo].[User]    Script Date: 9/19/2015 4:32:55 PM ******/
DROP TABLE [dbo].[User]
GO

/****** Object:  Table [dbo].[User]    Script Date: 9/19/2015 4:32:55 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[User](
	[ID] [INT] IDENTITY(1,1) NOT NULL,
	[Type] [NCHAR](10) NULL,
	[Environment] [NCHAR](10) NOT NULL,
	[Name] [NVARCHAR](50) NULL,
	[email] [NVARCHAR](255) NULL
) ON [PRIMARY]

GO

INSERT INTO [dbo].[User]
           ([Environment]
           ,[Type]
           ,[Name]
           ,[email])
     VALUES
           ('DEV'
           ,'USER'
           ,'Jean-Rene Roy'
           ,'jean-rene.roy@parl.gc.ca'),
		   ('DEV'
           ,'USER'
           ,'Brazdau, Aurelian'
           ,'Aurelian.Brazdau@parl.gc.ca'),
           ('TEST'
           ,'ADMIN'
           ,'Jean-Rene Roy'
           ,'jean-rene.roy@parl.gc.ca'),
           ('TEST'
           ,'ADMIN'
           ,'Brazdau, Aurelian'
           ,'Aurelian.Brazdau@parl.gc.ca')

GO
