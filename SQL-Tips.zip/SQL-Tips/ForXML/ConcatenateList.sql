
-- CONCATENATE email into one string with For XML
   DECLARE @Emails VARCHAR(200) ;
      SET @Emails = '' ;
      SELECT    @Emails = SUBSTRING(( SELECT    ';' + email
                                      FROM      dbo.Notification
                                      WHERE     [type] = 'USER'
                                                AND Environment = 'Dev'
                                    FOR
                                      XML PATH('')
                                    ), 2, 200)

SELECT @Emails AS [To]

RETURN;

jean-rene.roy@parl.gc.ca;Aurelian.Brazdau@parl.gc.ca

-- If I need a list of email in the TO and the CC for 2 different table

     SELECT    [TO] = SUBSTRING(( SELECT    ';' + email
                                      FROM      dbo.Notification
                                      WHERE     [type] = 'USER'
                                                AND Environment = 'Dev'
                                    FOR
                                      XML PATH('')
                                    ), 2, 200),
			   [CC] = SUBSTRING(( SELECT    ';' + email
                                      FROM      dbo.Notification
                                      WHERE     [type] = 'ADMIN'
                                    FOR
                                      XML PATH('')
                                    ), 2, 200)