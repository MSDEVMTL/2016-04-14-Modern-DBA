-- 02 For XML RAW  
--
USE ForXML
IF EXISTS(SELECT * FROM sys.tables WHERE NAME = N'T1')
	DROP TABLE dbo.T1
IF EXISTS(SELECT * FROM sys.tables WHERE NAME = N'T2')
	DROP TABLE dbo.T2
GO



CREATE TABLE T1(intCol int, XmlCol xml)
go
INSERT INTO T1 
VALUES(1, '<Root><ProductDescription ProductModelID="1" /></Root>')
go
SELECT * FROM t1
go


CREATE TABLE T2(XmlCol xml)
go
INSERT INTO T2(XmlCol) 
SELECT (SELECT XmlCol.query('/Root') 
        FROM T1 
        FOR XML AUTO,TYPE) 
go

SELECT * from T2
GO
