-- 01 For XML RAW  
--
-- RAW    mode generates a single <row> element per row  

USE ForXML
go

--CREATE TABLE Member (Numero INT, Fname VARCHAR(40),LName VARCHAR(40),Adddate DATETIME)     
--go

--INSERT INTO [dbo].[Member]
--           ([Numero]
--           ,[Fname]
--           ,[LName]
--           ,[Adddate])
--     VALUES
--			(1,'Jean-Rene','Roy',GETDATE()),
--		  (2,'Sandrine','Dubois',GETDATE())
--GO

SELECT fname, lname
        FROM member
        WHERE numero < 3
        FOR XML RAW
        
--- Auto   mode generates nesting in the resulting XML by using heuristics 
--- based on the way the SELECT statement 
--- Field as attribute. 
SELECT numero,fname, lname,adddate AS Mydate
        FROM member
        WHERE numero < 3
        FOR XML AUTO 




-- RAW, ELEMENTS
SELECT fname, lname
        FROM member
        WHERE numero < 3
        FOR XML RAW  ,ELEMENTS  
        
-- PATH mode together with the nested FOR XML query capability               
  SELECT fname, lname
        FROM member
        WHERE numero < 3
        FOR XML PATH    -- Check  the path option


   SELECT fname, lname
        FROM member
        WHERE numero < 3
        FOR XML PATH('MyRoot')     -- Check again the path option

  SELECT fname, lname
        FROM member
        WHERE numero < 3
        FOR XML PATH('')     -- Check again the path option
  
  SELECT fname  --+'-'+lname
        FROM member
        WHERE numero < 3
        FOR XML PATH('')  -- Try it after removing the comment
  
        
DECLARE @x xml
SET @x=(SELECT fname, lname
        FROM member
        WHERE numero < 3
        FOR XML PATH)
SELECT @x
---               