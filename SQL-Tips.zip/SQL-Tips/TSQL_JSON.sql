-- What is JSON: https://en.wikipedia.org/wiki/JSON

-- Creating JSON from SQL Server

select '{"Id":"'+ltrim(str([Id]))+'",'
      +'"Environment":"'+ltrim([Environment])+'",'
      +'"Type":"'+ltrim([Type]) +'",'
	  +'"Name":"'+rtrim([Name]) +'",'
	  +'"email":"'+rtrim([email]) +'"}'
	  AS MyJSON
FROM [dbo].[User]
WHERE id = 1

-- Result
-- {
--   "Id":"1"
--  ,"Environment":"DEV       "
--  ,"Type":"USER      "
--  ,"Name":"Jean-Rene Roy"
--  ,"email":"jean-rene.roy@parl.gc.ca"
-- }

