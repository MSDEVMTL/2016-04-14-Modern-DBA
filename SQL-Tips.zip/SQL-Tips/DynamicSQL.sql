-- This tips come from 
-- this link:https://www.mssqltips.com/sqlservertip/1568/run-a-dynamic-query-against-sql-server-without-dynamic-sql/

USE DevTeach
go

-- Query with no Dynamic SQL
DECLARE @MemberIDs VARCHAR(100);
SET @MemberIDs = '2';

SELECT  numero ,
        fname ,
        lname
FROM    dbo.member
WHERE   numero IN ( @MemberIDs );

RETURN;

 -- Will not work for more then one value
DECLARE @MemberIDs VARCHAR(100);
SET @MemberIDs = '2,5';

SELECT  numero ,
        fname ,
        lname
FROM    dbo.member
WHERE   numero IN ( @MemberIDs );

RETURN;

 -- Using Dynamic SQL
DECLARE @MemberIDs VARCHAR(100);
SET @MemberIDs = '3,5';
DECLARE @SQL VARCHAR(1000);
SET @SQL = 'Select * from dbo.member 
Where numero IN (' + @MemberIDs + ')';

EXEC (@SQL);

RETURN;

-- But what if we place the value in something we can query?
-- Let do it with XML

DECLARE @MemberIDs VARCHAR(100);
SET @MemberIDs = '2,5';

DECLARE @XmlStr XML;
SET @XmlStr = 
--Start Tag
    '<MemberID>' + --Replace all commas with an ending tag and start a new tag
REPLACE(@MemberIDs, ',', '</MemberID><MemberID>') + --End Tag 
    '</MemberID>';
-- Now select the value
SELECT  @XmlStr;

-- And now you can query the list

SELECT x.MemberID.value('.', 'INT') AS MemberID
FROM @XmlStr.nodes('//MemberID') x(MemberID)

-- list the row from member
SELECT numero ,
        fname ,
        lname
FROM    dbo.member AS A
INNER JOIN 
(SELECT x.MemberID.value('.', 'INT') AS MemberID
FROM @XmlStr.nodes('//MemberID') x(MemberID)) B
ON A.numero = B.MemberID