-- Sequence was introduce in SQL Server 2012

--DROP SEQUENCE dbo.NextNumber

CREATE SEQUENCE dbo.NextNumber
AS INT
START WITH 1
INCREMENT BY 1
MINVALUE 1
GO

-- Use it acros all table
DECLARE @NextNumber As INT = NEXT VALUE FOR dbo.NextNumber;
Select @NextNumber

SET @NextNumber = NEXT VALUE FOR dbo.NextNumber;
Select @NextNumber
